"""
AuraFin MCP Tool Wrappers
ADK-compatible function tools that call the MCP server layer.
"""

import sqlite3
import uuid
import json
import os
from datetime import datetime

DB_PATH = os.getenv("DB_PATH", "./data/aurafin.db")
FAIR_WAGE_FLOOR = float(os.getenv("FAIR_WAGE_FLOOR", 15.0))
ESCROW_RATIO = float(os.getenv("ESCROW_REPAYMENT_RATIO", 0.30))


def _get_db():
    os.makedirs(os.path.dirname(DB_PATH) if os.path.dirname(DB_PATH) else ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _init_db():
    conn = _get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS installments (
            id TEXT PRIMARY KEY,
            consumer_id TEXT NOT NULL,
            due_date TEXT NOT NULL,
            amount REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS referral_tokens (
            token TEXT PRIMARY KEY,
            consumer_id TEXT NOT NULL,
            skills TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            used INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS escrow_contracts (
            id TEXT PRIMARY KEY,
            token TEXT NOT NULL,
            employer_id TEXT NOT NULL,
            debt_amount REAL NOT NULL,
            repaid_amount REAL DEFAULT 0.0,
            wage_offered REAL NOT NULL,
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT NOT NULL,
            payload TEXT,
            timestamp TEXT DEFAULT CURRENT_TIMESTAMP
        );
    """)
    # Seed demo data if empty
    count = conn.execute("SELECT COUNT(*) FROM installments").fetchone()[0]
    if count == 0:
        conn.executemany(
            "INSERT INTO installments (id, consumer_id, due_date, amount, status) VALUES (?,?,?,?,?)",
            [
                ("INS-001", "CONSUMER-001", "2026-05-01", 850.0, "pending"),
                ("INS-002", "CONSUMER-001", "2026-06-01", 850.0, "pending"),
            ]
        )
    conn.commit()
    conn.close()


_init_db()


def check_installment_status(consumer_id: str) -> dict:
    """
    Check payment delay status for a consumer.
    Returns delay count and total overdue amount.
    Triggers mediation if delay_count >= 2.
    """
    conn = _get_db()
    rows = conn.execute(
        """SELECT * FROM installments
           WHERE consumer_id = ? AND status = 'pending'
           AND due_date < date('now')
           ORDER BY due_date ASC""",
        (consumer_id,)
    ).fetchall()

    delay_count = len(rows)
    total_overdue = sum(r["amount"] for r in rows)

    conn.execute(
        "INSERT INTO audit_log (event, payload) VALUES (?, ?)",
        ("check_installment_status", json.dumps({
            "consumer_id": consumer_id,
            "delay_count": delay_count
        }))
    )
    conn.commit()
    conn.close()

    return {
        "consumer_id": consumer_id,
        "delay_count": delay_count,
        "total_overdue": round(total_overdue, 2),
        "trigger_mediation": delay_count >= 2,
        "checked_at": datetime.utcnow().isoformat()
    }


def generate_referral_token(consumer_id: str, skills: list) -> dict:
    """
    Generate a privacy-preserving tokenized referral.
    Financial data is never attached — only skill profile.
    GDPR-compliant by design.
    """
    token = str(uuid.uuid4())
    skills_json = json.dumps(skills)

    conn = _get_db()
    conn.execute(
        "INSERT INTO referral_tokens (token, consumer_id, skills) VALUES (?, ?, ?)",
        (token, consumer_id, skills_json)
    )
    conn.execute(
        "INSERT INTO audit_log (event, payload) VALUES (?, ?)",
        ("generate_referral_token", json.dumps({
            "consumer_id": consumer_id,
            "token": token
        }))
    )
    conn.commit()
    conn.close()

    return {
        "token": token,
        "skills_attached": skills,
        "financial_data_exposed": False,
        "gdpr_compliant": True,
        "created_at": datetime.utcnow().isoformat()
    }


def query_job_market(skills: list, location: str = "remote") -> dict:
    """
    Query live job market demand for given skills.
    Returns ranked employer matches with fair-wage enforcement.
    Only returns fair_wage_compliant matches.
    """
    mock_market = [
        {"role": "Operations Coordinator",  "match_skills": ["logistics", "coordination", "planning", "admin"], "avg_wage": 22.0, "employer_id": "EMP-001"},
        {"role": "Data Entry Specialist",   "match_skills": ["excel", "data", "typing", "admin"],               "avg_wage": 18.5, "employer_id": "EMP-002"},
        {"role": "Customer Success Agent",  "match_skills": ["communication", "crm", "support", "admin"],       "avg_wage": 20.0, "employer_id": "EMP-003"},
        {"role": "Warehouse Associate",     "match_skills": ["physical", "logistics", "inventory"],             "avg_wage": 19.0, "employer_id": "EMP-004"},
        {"role": "Accounting Assistant",    "match_skills": ["accounting", "finance", "excel", "data"],         "avg_wage": 24.0, "employer_id": "EMP-005"},
        {"role": "Project Coordinator",     "match_skills": ["coordination", "communication", "planning"],      "avg_wage": 23.0, "employer_id": "EMP-006"},
    ]

    skills_lower = [s.lower() for s in skills]
    matches = []
    for job in mock_market:
        overlap = len(set(skills_lower) & set(job["match_skills"]))
        if overlap > 0:
            score = round(overlap / len(job["match_skills"]), 2)
            wage_ok = job["avg_wage"] >= FAIR_WAGE_FLOOR
            monthly = round(job["avg_wage"] * ESCROW_RATIO * 4, 2)
            matches.append({
                "role": job["role"],
                "employer_id": job["employer_id"],
                "match_score": score,
                "avg_wage": job["avg_wage"],
                "fair_wage_compliant": wage_ok,
                "monthly_repayment": monthly,
                "consumer_take_home_monthly": round(job["avg_wage"] * (1 - ESCROW_RATIO) * 4, 2),
                "debt_clearance_months": round(3500 / monthly, 1) if monthly > 0 else None,
            })

    matches.sort(key=lambda x: x["match_score"], reverse=True)
    matches = [m for m in matches if m["fair_wage_compliant"]]

    return {
        "query_skills": skills,
        "location": location,
        "fair_wage_floor": FAIR_WAGE_FLOOR,
        "matches_found": len(matches),
        "top_matches": matches[:3]
    }


def activate_escrow_contract(
    token: str,
    employer_id: str,
    wage_offered: float,
    debt_amount: float
) -> dict:
    """
    Activate a smart escrow contract.
    Consumer voluntarily assigns repayment portion of wage.
    Enforces fair wage floor — blocks contract if violated.
    """
    if wage_offered < FAIR_WAGE_FLOOR:
        return {
            "success": False,
            "reason": f"Wage ${wage_offered}/hr is below fair wage floor ${FAIR_WAGE_FLOOR}/hr. Contract BLOCKED.",
            "consumer_protected": True,
            "escalate_to_oversight": True
        }

    conn = _get_db()
    token_row = conn.execute(
        "SELECT * FROM referral_tokens WHERE token = ? AND used = 0",
        (token,)
    ).fetchone()

    if not token_row:
        conn.close()
        return {
            "success": False,
            "reason": "Invalid or already-used referral token.",
            "escalate_to_oversight": True
        }

    contract_id = f"ESC-{str(uuid.uuid4())[:8].upper()}"
    monthly_repayment = round(wage_offered * ESCROW_RATIO * 4 * 40, 2)  # hourly * ratio * 4wks * 40hrs
    estimated_months = round(debt_amount / monthly_repayment, 1) if monthly_repayment > 0 else None
    take_home = round(wage_offered * (1 - ESCROW_RATIO) * 4 * 40, 2)

    conn.execute(
        """INSERT INTO escrow_contracts
           (id, token, employer_id, debt_amount, wage_offered, status)
           VALUES (?, ?, ?, ?, ?, 'active')""",
        (contract_id, token, employer_id, debt_amount, wage_offered)
    )
    conn.execute("UPDATE referral_tokens SET used = 1 WHERE token = ?", (token,))
    conn.execute(
        "INSERT INTO audit_log (event, payload) VALUES (?, ?)",
        ("activate_escrow_contract", json.dumps({
            "contract_id": contract_id,
            "employer_id": employer_id,
            "debt_amount": debt_amount,
            "wage_offered": wage_offered
        }))
    )
    conn.commit()
    conn.close()

    return {
        "success": True,
        "contract_id": contract_id,
        "employer_id": employer_id,
        "wage_offered_hourly": wage_offered,
        "escrow_ratio": ESCROW_RATIO,
        "monthly_repayment_to_lender": monthly_repayment,
        "consumer_monthly_take_home": take_home,
        "debt_amount": debt_amount,
        "estimated_debt_clearance_months": estimated_months,
        "fair_wage_floor_enforced": True,
        "consumer_protected": True,
        "financial_data_to_employer": False,
        "status": "active",
        "activated_at": datetime.utcnow().isoformat()
    }
