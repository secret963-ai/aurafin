# AuraFin Architecture

## Overview

AuraFin operates as a **Mediation-to-Work pipeline** — a sequential multi-agent workflow
that transforms a payment delay event into an employment outcome.

## Agent Pipeline

```
Consumer Payment Delay (2 installments)
           │
           ▼
    ┌─────────────┐
    │ Trigger     │  check_installment_status()
    │ Agent       │  → delay_count, total_overdue, trigger_mediation
    └──────┬──────┘
           │ trigger_mediation = True
           ▼
    ┌─────────────┐
    │ Mediation   │  generate_referral_token()
    │ Agent       │  → token (ZKP-anonymized, GDPR-ready)
    └──────┬──────┘
           │
           ▼
    ┌─────────────┐
    │ Skill       │  query_job_market()
    │ Matcher     │  → top_matches (fair_wage_compliant only)
    └──────┬──────┘
           │ match found?
    ┌──────┴──────┐
    │ No          │ Yes
    ▼             ▼
┌────────┐  ┌──────────┐
│Oversight│  │ Escrow   │  activate_escrow_contract()
│Agent    │  │ Agent    │  → contract_id, monthly_repayment
│(HITL)  │  └────┬─────┘
└────────┘       │
                 ▼
        Debt Cleared / Job Secured ✓
```

## MCP Tools

| Tool | Input | Output |
|------|-------|--------|
| `check_installment_status` | consumer_id | delay_count, total_overdue, trigger_mediation |
| `generate_referral_token` | consumer_id, skills | token, gdpr_compliant, financial_data_exposed=False |
| `query_job_market` | skills, location | top_matches (fair_wage_compliant) |
| `activate_escrow_contract` | token, employer_id, wage, debt | contract_id, monthly_repayment, clearance_months |

## Database Schema

```sql
installments        -- payment schedule ledger
referral_tokens     -- anonymized consumer tokens
escrow_contracts    -- active smart contracts
audit_log           -- full decision trail
```

## Ethical Constraints (Enforced at Code Level)

1. `financial_data_exposed = False` — always hardcoded in token generation
2. `wage_offered < FAIR_WAGE_FLOOR` → contract BLOCKED — not optional
3. `used = 0` check on token — prevents replay attacks
4. All events written to `audit_log` — full regulatory trail
