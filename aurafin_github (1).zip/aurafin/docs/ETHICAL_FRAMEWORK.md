# AuraFin Ethical Framework

## Core Principle

AuraFin is a **voluntary social safety net**, not a punitive mechanism.
Every ethical protection is enforced at the code level — not by policy.

## Three Non-Negotiable Guarantees

### 1. Privacy by Architecture
- Referral tokens are UUID-based, containing zero financial data
- `financial_data_exposed` is hardcoded `False` in `generate_referral_token()`
- Employers receive only: skills, availability, location
- Debt history is structurally inaccessible to employers

### 2. Fair Wage Floor
- Minimum wage threshold enforced in `activate_escrow_contract()`
- If `wage_offered < FAIR_WAGE_FLOOR`: contract is BLOCKED, not warned
- Configurable via `FAIR_WAGE_FLOOR` env variable (default: $15.00/hr)
- Prevents exploitation of financially vulnerable workers

### 3. Voluntary Participation
- Consumer opt-in required at mediation stage
- Exit available at any pipeline stage
- Pre-signed amendment agreement governs participation
- Oversight Agent handles all exit requests

## Human-in-the-Loop

The Oversight Agent escalates when:
- No employer match found
- Fair wage violation detected
- Consumer requests human review
- Disputed debt amount

Human mediators retain final authority on all escalated cases.

## Audit Trail

Every tool call writes to `audit_log`:
- Event type
- Payload (anonymized)
- Timestamp

This ensures full regulatory compliance and consumer protection.

## Consumer Rights (Always Active)

- Right to exit the voluntary framework at any time
- Right to dispute debt amount before escrow activation
- Right to request alternative employer matches
- Right to human mediator review on request
- Right to data privacy (financial history never shared)
